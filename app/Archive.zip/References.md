http://stackoverflow.com/questions/37823865/problems-with-navcontroller-when-unit-testing-an-ionic-2-app
https://cjcoffey.com/2016/08/22/Ionic2Tutorial2
http://tobyho.com/2011/12/15/jasmine-spy-cheatsheet/
https://jasmine.github.io/2.0/introduction.html#section-Spies
http://www.sparkbit.pl/typescript-decorators/
