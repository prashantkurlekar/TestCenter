export interface BasePage {
  title: string;
}
