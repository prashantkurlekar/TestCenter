import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { ComponentsModule } from '../../components';

@NgModule({
  declarations: [],
  imports: [IonicModule, ComponentsModule],
  exports: [],
  entryComponents: [],
  providers: [],
})
export class MemberSectionModule { }
