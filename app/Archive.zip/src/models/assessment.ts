export interface Assessment {
  id: any;
  name: string;
  shortName?: string;
  description?: string;
  labels?: Array<string>;
  createdDate?: Date;
}
