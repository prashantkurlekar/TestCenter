export interface Course {
  id: any;
  name?: string;
  description?: string;
  categories?: Array<string>;
  createdDate?: Date;
}
