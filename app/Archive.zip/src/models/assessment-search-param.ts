export interface AssessmentSearchParameters {
  pageSize?: number;
  pageNumber?: number;
}
