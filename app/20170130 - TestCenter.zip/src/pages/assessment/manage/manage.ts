import { Logger } from './../../../providers/logger';
import { AssessmentService } from './../../../services/assessment/assessment.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { NavController, NavParams } from 'ionic-angular';
import { Utils } from './../../../providers';
import { AssessmentIntroductionPage } from './../introduction/introduction';

@Component({
  selector: 'page-manageassessment',
  templateUrl: 'manage.html'
})
export class ManageAssessmentPage implements OnInit {

  public title: string;
  public assessmentForm: FormGroup;
  public assessment: any;
  public formErrors = {
    name: '',
    shortName: '',
    description: '',
    categories: '',
  };
  public validationMessages = {
    name: {
      required: 'Name is required.',
      maxlength: 'Name cannot be more than 50 characters.',
    },
    shortName: {
      required: 'Short name is required.',
      maxlength: 'Short name cannot be more than 10 characters long.',
    },
    description: {
      required: 'Description is required.',
      maxlength: 'Description cannot be more than 100 characters long.',
    },
    categories: {
      required: 'Categories is required.',
    },
  };

  constructor(public navCtrl: NavController, public navParams: NavParams, private formBuilder: FormBuilder,
    public assessmentService: AssessmentService, public logger: Logger) {
    this.logger.log(`ManageAssessmentPage.constructor`);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AssessmentPage');
  }

  ngOnInit() {
    this.logger.log(`ManageAssessmentPage.ngOnInit`);
    this.title = 'Assessment';
    this.createFormGroup();
  }

  public createFormGroup(): void {
    this.logger.log(`ManageAssessmentPage.createFormGroup`);
    this.assessmentForm = new FormGroup({
      name: new FormControl('Prashant',
        Validators.compose([Validators.required, Validators.maxLength(50)])),
      shortName: new FormControl('PK',
        Validators.compose([Validators.required, Validators.maxLength(10)])),
      description: new FormControl('Prashant Kurlekar',
        Validators.compose([Validators.required, Validators.maxLength(100)])),
      categories: new FormControl(['cat1'],
        Validators.required),
    });
    this.assessmentForm.valueChanges.subscribe(() => Utils.onFormValueChanged(this.assessmentForm, this.formErrors, this.validationMessages));
  }

  public onSubmit(): void {
    this.logger.log(`ManageAssessmentPage.onSubmit`);
    this.assessmentService.createAssessment(this.extractAssessmentDetails())
      .then(response => {
        this.assessment = response;
        this.navCtrl.push(AssessmentIntroductionPage, { assessment: this.assessment });
      }).catch(error => {
        this.logger.handleError(error);
      });
  }

  private extractAssessmentDetails(): any {
    return {
      name: this.assessmentForm.value.name,
      shortName: this.assessmentForm.value.shortName,
      description: this.assessmentForm.value.description,
      categories: this.assessmentForm.value.categories,
    };
  }

}
