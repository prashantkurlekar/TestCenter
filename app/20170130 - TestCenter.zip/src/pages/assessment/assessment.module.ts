import { NgModule } from '@angular/core';
import { AssessmentDetailPage, ManageAssessmentPage, AssessmentIntroductionPage } from './';
import { IonicModule } from 'ionic-angular';

const pages = [
  AssessmentDetailPage, ManageAssessmentPage, AssessmentIntroductionPage,
];

@NgModule({
  declarations: pages,
  imports: [
    IonicModule,
  ],
  entryComponents: pages,
})
export class AssessmentModule { }
