import { Logger, SafeHttp, Utils } from './../../providers';
import { AppConfig } from './../../app/app.config';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';

@Injectable()
export class AssessmentService {
  constructor(public http: SafeHttp, public logger: Logger) { }

  public createAssessment(assessment: any): Promise<any> {
    this.logger.log(`AssessmentService.createAssessment`);
    return this.http.post(AppConfig.apiAssessment, assessment, Utils.requestOptions).toPromise()
      .then(response => {
        return response;
      }).catch(() => this.logger.handleError);
  }

}
