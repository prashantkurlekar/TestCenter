import { Logger } from './../../providers/logger';
import { SafeHttp } from './../../providers/safe-http';
import { AssessmentService } from './assessment.service';
import { TestBed, inject, async } from '@angular/core/testing';
import { BaseRequestOptions, Http } from '@angular/http';
import { MockBackend } from '@angular/http/testing';

describe('Service: AssessmentService', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      providers: [
        AssessmentService, Logger,
        MockBackend, BaseRequestOptions,
        {
          provide: SafeHttp, useFactory: (mockBackend: MockBackend, options: BaseRequestOptions) => {
            return new Http(mockBackend, options);
          }, deps: [MockBackend, BaseRequestOptions]
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    spyOn(console, 'log');
  });

  it('should initialize service',
    async(inject([AssessmentService], (service: AssessmentService) => {
      expect(service).toBeTruthy();
    }))
  );

  it('should call api and create assessment',
    async(inject([AssessmentService], (service: AssessmentService) => {
      const assessment = {};
      service.createAssessment(assessment).then(result => {
        expect(result).toBe(true);
      });
    }))
  );
});
