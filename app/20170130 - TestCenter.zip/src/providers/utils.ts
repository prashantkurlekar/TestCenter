import { Headers, RequestOptions } from '@angular/http';

export class Utils {
  public static requestOptions(): RequestOptions {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    return new RequestOptions({ headers: headers, withCredentials: true });
  }

  public static onFormValueChanged(form: any, formErrors: any, validationMessages: any): void {
    if (!form) return;
    for (const field in formErrors) {
      formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = validationMessages[field];
        for (const key in control.errors) {
          formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }
}
