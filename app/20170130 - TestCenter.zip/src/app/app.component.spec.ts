import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { IonicModule } from 'ionic-angular';
import { TestCenterApp } from './app.component';
import { TabsPage } from './../pages/tabs/tabs';

let fixture: ComponentFixture<TestCenterApp>;
let componentInstance: TestCenterApp;

describe('App: TestCenterApp', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TestCenterApp],
      providers: [],
      imports: [
        IonicModule.forRoot(TestCenterApp)
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestCenterApp);
    componentInstance = fixture.componentInstance;

    spyOn(console, 'log');
  });

  afterEach(() => {
    fixture.destroy();
    componentInstance = null;
  });

  it('is initialized', () => {
    expect(fixture).toBeTruthy();
    expect(componentInstance).toBeTruthy();
  });

  it('initialises with a root page of TabsPage', () => {
    expect(componentInstance['rootPage']).toBe(TabsPage);
  });

});
